package com.jl.tcs;

/**
 * 作者： 贺钧丽 .
 * 时间: 2021
 * 功能简介：得分记录
 */
public interface TcsScoreListener {
    void onTCSScore(int score);
}
