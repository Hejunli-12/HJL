package com.jl.tcs;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity
        extends AppCompatActivity
        implements TcsScoreListener,
        View.OnClickListener {

    private TcsView tcsView;
    private ImageButton restartView;
    private Button pauseButtonView;
    private Button upButtonView;
    private Button downButtonView;
    private Button lButtonView;
    private Button rButtonView;
    private TextView scoreTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        scoreTextView = findViewById(R.id.tv_score);
        tcsView = findViewById(R.id.tcs_22);
        restartView = findViewById(R.id.btn_restart);
        pauseButtonView = findViewById(R.id.btn_pause);
        upButtonView = findViewById(R.id.btn_up);
        downButtonView = findViewById(R.id.btn_down);
        lButtonView = findViewById(R.id.btn_l);
        rButtonView = findViewById(R.id.btn_r);
        initEvent();
    }

    /**
     * initial event
     */
    private void initEvent() {
        tcsView.setOnClickListener(this);
        restartView.setOnClickListener(this);
        pauseButtonView.setOnClickListener(this);
        upButtonView.setOnClickListener(this);
        downButtonView.setOnClickListener(this);
        lButtonView.setOnClickListener(this);
        rButtonView.setOnClickLstener(this);
    }

    @Override
    public void onTCSScore(int score) {
        if (scoreTextView != null) {
            scoreTextView.setText(String.valueOf(score));
        }
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tcs_22:
                tcsView.invalidate();
                break;
            case R.id.btn_restart:
                tcsView.restart();
                break;
            case R.id.btn_pause:
                tcsView.pause();
                break;
            case R.id.btn_up:
                tcsView.changeDirection(0);
                break;
            case R.id.btn_down:
                tcsView.changeDirection(-1);
                break;
            case R.id.btn_l:
                tcsView.changeDirection(1);
                break;
            case R.id.btn_r:
                tcsView.changeDirection(2);
                break;
            default:
                break;
        }
    }




    interface ClickAction extends View.OnClickListener {

        <V extends View> V findViewById(@IdRes int id);

        @Override
        default void onClick(View v) {
            // 默认不实现，让子类实现
        }

        default void setOnClickListener(@IdRes int... ids) {
            for (int id : ids) {
                findViewById(id).setOnClickListener(this);
            }
        }

        default void setOnClickListener(View... views) {
            for (View view : views) {
                view.setOnClickListener(this);
            }
        }
    }

}
